
package com.example.visimos

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

class MotionOverlayView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private var rect: Rect? = null
    private val paint = Paint().apply {
        style = Paint.Style.STROKE
        strokeWidth = 18f
        isAntiAlias = true
        color = Color.WHITE
        maskFilter = BlurMaskFilter(30f, BlurMaskFilter.Blur.NORMAL)
    }

    fun setMotionRect(r: Rect?) {
        rect = r
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        // Draw soft halo centered effect
        rect ?: return
        val cx = width/2f
        val cy = height/2f
        val radius = (width.coerceAtMost(height) * 0.35f)
        for (i in 0..3) {
            paint.alpha = (255/(i+2))
            paint.strokeWidth = 18f + i*6
            canvas.drawCircle(cx, cy, radius, paint)
        }
    }
}
