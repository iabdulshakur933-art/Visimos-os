
package com.example.visimos

import android.graphics.Rect
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import kotlin.math.abs

class MotionAnalyzer(private val onMotionFound: (Rect?) -> Unit) : ImageAnalysis.Analyzer {
    private var previous: ByteArray? = null
    override fun analyze(image: ImageProxy) {
        val buffer = image.planes[0].buffer
        val data = ByteArray(buffer.remaining())
        buffer.get(data)
        val prev = previous
        if (prev == null) {
            previous = data
            onMotionFound(null)
            image.close()
            return
        }
        var minX = Int.MAX_VALUE
        var minY = Int.MAX_VALUE
        var maxX = 0
        var maxY = 0
        var count = 0
        val w = image.width
        val h = image.height
        for (y in 0 until h step 2) {
            for (x in 0 until w step 2) {
                val idx = y*w + x
                val d = abs((data[idx].toInt() and 0xff) - (prev[idx].toInt() and 0xff))
                if (d > 20) {
                    count++
                    if (x < minX) minX = x
                    if (y < minY) minY = y
                    if (x > maxX) maxX = x
                    if (y > maxY) maxY = y
                }
            }
        }
        previous = data
        if (count > 1000) onMotionFound(Rect(minX, minY, maxX, maxY)) else onMotionFound(null)
        image.close()
    }
}
